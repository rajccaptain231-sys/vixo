import { PrismaClient } from '@prisma/client';
const db = new PrismaClient();
async function main(){
  const categories=['Entertainment','Music','Gaming','Technology','Education','Sports','News','Comedy','Lifestyle','Travel','Science','Movies','Podcasts'];
  for(const name of categories) await db.category.upsert({where:{name},update:{},create:{name,slug:name.toLowerCase().replace(/[^a-z0-9]+/g,'-')}});
}
main().finally(()=>db.$disconnect());
