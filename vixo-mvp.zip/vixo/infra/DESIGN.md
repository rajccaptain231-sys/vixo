# Production infrastructure design

## Edge
Cloud DNS -> WAF -> CDN -> Next.js and signed HLS/object delivery.

## Compute
Separate stateless web/API deployments from FFmpeg workers and notification/analytics workers. Autoscale API on CPU/request latency and workers on queue depth.

## Media pipeline
1. Client asks API for an upload session.
2. API validates identity, quota and metadata.
3. API returns short-lived signed object-storage upload URL(s).
4. Client uploads directly to object storage.
5. Storage event enqueues processing job.
6. Worker validates container/codec, scans file, extracts metadata, creates thumbnails and HLS renditions, writes immutable output keys.
7. API marks video READY only after required assets exist.
8. CDN serves HLS/thumbnail assets; original uploads remain private.

## Reliability
PITR database backups, cross-zone deployment, dead-letter queues, idempotent processing jobs, health probes, graceful shutdown, structured logs, metrics and distributed traces.

## Security controls
WAF, rate limits, origin protection, signed URLs, least-privilege IAM, KMS encryption, secrets manager, dependency scanning, SAST, container scanning, audit logs, moderation actions and incident-response procedures.
