# Security model

- Passwords: Argon2id only; never log credentials.
- Sessions: random opaque tokens stored hashed server-side and delivered in HttpOnly/Secure/SameSite cookies.
- OAuth: authorization-code + PKCE, server-side token exchange.
- Authorization: deny by default; owner checks and RBAC on every privileged mutation.
- Input: Zod/schema validation, bounded request bodies, parameterized ORM queries.
- Uploads: signed direct-to-object-storage uploads, content sniffing, extension/MIME consistency checks, malware scanning and transcoding isolation.
- Web: CSP, HSTS in production, frame/embedding policy, XSS-safe rendering, CSRF protection for cookie-authenticated mutations.
- Abuse: per-IP/user rate limits, bot signals, velocity checks, spam heuristics, report queues and audit logs.
- Secrets: environment variables for local development; cloud secret manager in production.
- Payments: server-side provider SDK, webhook signature verification, idempotency keys, ledger/audit records; no client-side trust.
