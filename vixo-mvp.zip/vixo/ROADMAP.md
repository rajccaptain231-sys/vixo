# Vixo MVP Roadmap

1. Foundation: repo, Docker services, schema, API/web shells, CI.
2. Identity: signup/login/logout/session, profile/channel creation.
3. Media: create video records, signed-upload abstraction, processing state machine, HLS worker interface.
4. Playback/discovery: watch page, feed, search, watch progress.
5. Engagement: likes, follows, comments/replies, saves/playlists.
6. Studio: upload management and core analytics.
7. Admin: RBAC, reports, moderation queue, audit log.
8. Hardening: rate limits, security headers, tests, observability, backups and deployment.
9. Phase 2+: Shorts, notifications, advanced moderation and recommendation improvements.
