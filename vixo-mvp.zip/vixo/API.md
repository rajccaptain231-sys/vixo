# Vixo API Specification (MVP)

Base URL: `/api/v1`

## Auth
- POST `/auth/signup` {email,password,username,displayName}
- POST `/auth/login` {email,password}
- POST `/auth/logout`
- GET `/auth/me`

## Videos
- GET `/videos?cursor=&limit=`
- GET `/videos/:slug`
- POST `/videos` authenticated
- PATCH `/videos/:id` owner/admin
- POST `/videos/:id/like`
- DELETE `/videos/:id/like`

## Channels
- GET `/channels/:username`
- POST `/channels/:id/follow`
- DELETE `/channels/:id/follow`

## Comments
- GET `/videos/:videoId/comments`
- POST `/videos/:videoId/comments`
- POST `/comments/:id/reply`
- DELETE `/comments/:id`

## Discovery
- GET `/search?q=&type=&cursor=`
- GET `/feed`

Production additions: presigned upload endpoints, upload sessions, processing-job status, notifications, playlists, moderation, admin, analytics, OAuth callbacks and payment webhooks.
