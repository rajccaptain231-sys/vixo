# Vixo Product Architecture

## 1. Product boundaries

Core domains: identity, profiles/channels, media ingestion, media processing, playback, engagement, discovery/search, notifications, creator analytics, moderation, administration and monetization.

## 2. Runtime topology

Browser/mobile -> CDN/WAF -> Next.js web -> Fastify API -> PostgreSQL/Redis.
Media upload -> signed object-storage URL -> object storage -> queue -> FFmpeg worker -> HLS/thumbnail assets -> CDN.
Analytics events -> API/event queue -> aggregate tables/warehouse later.

## 3. Data model

The Prisma schema models users, profiles, channels, videos, assets, thumbnails, categories/tags, comments/replies, reactions, follows/subscriptions, playlists, watch history/progress, notifications, reports/moderation, admin users/audit logs and analytics.

## 4. API principles

Versioned REST under `/api/v1`. JSON responses use `{data, error, requestId}`. Authentication and authorization happen server-side. Pagination uses cursor-based pagination for feeds and comments. Mutations are idempotency-key capable where money/media jobs are involved.

## 5. Deployment

Local: Docker Compose. Production: containerized web/API/workers on a managed Kubernetes/container platform; PostgreSQL managed with PITR backups; Redis managed; object storage + CDN; WAF; centralized logs/metrics/traces; secret manager; CI/CD with migrations as a controlled deployment step.

## 6. Security architecture

TLS everywhere, secure cookies, Argon2id, OAuth via server-side code flow, CSRF protections for cookie-authenticated state-changing requests, strict CORS, rate limits, request-size limits, MIME/extension/content validation, malware scanning, object storage isolation, RBAC, audit logs, moderation workflow and least-privilege cloud IAM.

## 7. Recommendation architecture

MVP ranker: candidate sources (followed creators, recent category interest, popular/fresh videos, continue-watching) -> safety/visibility filters -> deterministic score using recency, watch completion, engagement and user affinity -> diversity pass. Later replace ranker behind a `RecommendationEngine` interface with a trained retrieval/ranking system.

## 8. Roadmap

Phase 1: auth, channels, upload metadata, playback, feed, search, engagement, comments, studio basics, admin basics.
Phase 2: Shorts, notifications, playlists, moderation queues, analytics.
Phase 3: monetization, ads, memberships/tips, advanced analytics.
Phase 4: native apps, AI creator tools, internationalization, large-scale recommendation/search infrastructure.
