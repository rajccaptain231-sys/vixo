import { z } from 'zod';
export const env = z.object({
 NODE_ENV:z.enum(['development','test','production']).default('development'),
 WEB_URL:z.string().url().default('http://localhost:3000'),
 API_URL:z.string().url().default('http://localhost:4000'),
 DATABASE_URL:z.string().min(1),
 SESSION_SECRET:z.string().min(32)
}).parse(process.env);
