import 'dotenv/config';
import crypto from 'node:crypto';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import cookie from '@fastify/cookie';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { z } from 'zod';
import { env } from './config.js';
import { db } from './db.js';
import { clearSession, createSession, currentUser, hashPassword, verifyPassword } from './auth.js';

const app=Fastify({logger:true,bodyLimit:2*1024*1024});
await app.register(helmet);
await app.register(cookie);
await app.register(cors,{origin:env.WEB_URL,credentials:true});
await app.register(rateLimit,{max:120,timeWindow:'1 minute'});

app.get('/health',async()=>({ok:true,service:'vixo-api'}));
app.setErrorHandler((error,request,reply)=>{request.log.error(error); reply.status(error.statusCode&&error.statusCode<500?error.statusCode:500).send({error:{code:'REQUEST_FAILED',message:error.statusCode&&error.statusCode<500?error.message:'Request failed'},requestId:request.id});});

app.post('/api/v1/auth/signup',async(req,reply)=>{
 const body=z.object({email:z.string().email(),password:z.string().min(8).max(128),username:z.string().regex(/^[a-zA-Z0-9_]{3,30}$/),displayName:z.string().min(1).max(80)}).parse(req.body);
 const passwordHash=await hashPassword(body.password);
 const user=await db.user.create({data:{email:body.email.toLowerCase(),passwordHash,username:body.username.toLowerCase(),displayName:body.displayName,channel:{create:{name:body.displayName,username:body.username.toLowerCase()}}},select:{id:true,email:true,username:true,displayName:true}});
 await createSession(user.id,reply); return reply.status(201).send({data:user});
});
app.post('/api/v1/auth/login',async(req,reply)=>{
 const body=z.object({email:z.string().email(),password:z.string().min(1)}).parse(req.body);
 const user=await db.user.findUnique({where:{email:body.email.toLowerCase()}});
 if(!user || user.status!=='ACTIVE' || !(await verifyPassword(user.passwordHash,body.password))) return reply.status(401).send({error:{code:'INVALID_CREDENTIALS',message:'Invalid email or password'}});
 await createSession(user.id,reply); return {data:{id:user.id,email:user.email,username:user.username,displayName:user.displayName}};
});
app.post('/api/v1/auth/logout',async(req,reply)=>{await clearSession(req,reply); return {data:{ok:true}}});
app.get('/api/v1/auth/me',async(req,reply)=>{const user=await currentUser(req); if(!user)return reply.status(401).send({error:{code:'UNAUTHENTICATED',message:'Sign in required'}}); return {data:{id:user.id,email:user.email,username:user.username,displayName:user.displayName,channel:user.channel}}});

app.get('/api/v1/videos',async(req)=>{
 const q=z.object({limit:z.coerce.number().min(1).max(50).default(20),cursor:z.string().optional()}).parse(req.query);
 const videos=await db.video.findMany({where:{visibility:'PUBLIC',status:'READY'},orderBy:{publishedAt:'desc'},take:q.limit,skip:q.cursor?1:0,cursor:q.cursor?{id:q.cursor}:undefined,include:{channel:true,thumbnails:{where:{isPrimary:true},take:1}}});
 return {data:videos.map(v=>({...v,views:v.views.toString()})),nextCursor:videos.length===q.limit?videos.at(-1)?.id:null};
});
app.get('/api/v1/videos/:slug',async(req,reply)=>{const {slug}=z.object({slug:z.string()}).parse(req.params); const v=await db.video.findUnique({where:{slug},include:{channel:true,category:true,tags:{include:{tag:true}},thumbnails:true,assets:true}}); if(!v||v.visibility==='PRIVATE'||v.status!=='READY')return reply.status(404).send({error:{code:'NOT_FOUND',message:'Video not found'}}); await db.video.update({where:{id:v.id},data:{views:{increment:1}}}); return {data:{...v,views:(v.views+1n).toString()}};});
app.get('/api/v1/channels/:username',async(req,reply)=>{const {username}=z.object({username:z.string()}).parse(req.params); const c=await db.channel.findUnique({where:{username:username.toLowerCase()},include:{user:true,videos:{where:{visibility:'PUBLIC',status:'READY'},orderBy:{publishedAt:'desc'},take:24,include:{thumbnails:{where:{isPrimary:true},take:1}}}}}); if(!c)return reply.status(404).send({error:{code:'NOT_FOUND',message:'Channel not found'}}); return {data:{...c,videos:c.videos.map(v=>({...v,views:v.views.toString()}))}};});

app.get('/api/v1/feed',async(req)=>{const user=await currentUser(req); const videos=await db.video.findMany({where:{visibility:'PUBLIC',status:'READY'},orderBy:[{publishedAt:'desc'}],take:30,include:{channel:true,thumbnails:{where:{isPrimary:true},take:1}}}); return {data:videos.map(v=>({...v,views:v.views.toString()})),personalized:Boolean(user)};});
app.get('/api/v1/search',async(req)=>{const {q,limit}=z.object({q:z.string().min(1).max(100),limit:z.coerce.number().min(1).max(50).default(20)}).parse(req.query); const videos=await db.video.findMany({where:{visibility:'PUBLIC',status:'READY',OR:[{title:{contains:q,mode:'insensitive'}},{description:{contains:q,mode:'insensitive'}}]},take:limit,orderBy:{publishedAt:'desc'},include:{channel:true,thumbnails:{where:{isPrimary:true},take:1}}}); const channels=await db.channel.findMany({where:{OR:[{name:{contains:q,mode:'insensitive'}},{username:{contains:q,mode:'insensitive'}}]},take:10}); return {data:{videos,channels}};});

app.post('/api/v1/videos',async(req,reply)=>{const user=await currentUser(req); if(!user)return reply.status(401).send({error:{code:'UNAUTHENTICATED',message:'Sign in required'}}); if(!user.channel)return reply.status(400).send({error:{code:'NO_CHANNEL',message:'Create a channel first'}}); const body=z.object({title:z.string().min(1).max(150),description:z.string().max(5000).optional(),visibility:z.enum(['PUBLIC','UNLISTED','PRIVATE','SCHEDULED']).default('PRIVATE'),categoryId:z.string().optional()}).parse(req.body); const slug=`${body.title.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60)}-${crypto.randomUUID().slice(0,8)}`; const v=await db.video.create({data:{ownerId:user.id,channelId:user.channel.id,slug,title:body.title,description:body.description,visibility:body.visibility,categoryId:body.categoryId}}); return reply.status(201).send({data:v});});

app.post('/api/v1/videos/:id/like',async(req,reply)=>{const user=await currentUser(req); if(!user)return reply.status(401).send({error:{code:'UNAUTHENTICATED',message:'Sign in required'}}); const {id}=z.object({id:z.string()}).parse(req.params); await db.reaction.upsert({where:{userId_videoId:{userId:user.id,videoId:id}},update:{type:'LIKE'},create:{userId:user.id,videoId:id,type:'LIKE'}}); return {data:{ok:true}};});
app.post('/api/v1/videos/:videoId/comments',async(req,reply)=>{const user=await currentUser(req); if(!user)return reply.status(401).send({error:{code:'UNAUTHENTICATED',message:'Sign in required'}}); const {videoId}=z.object({videoId:z.string()}).parse(req.params); const body=z.object({body:z.string().min(1).max(2000),parentId:z.string().optional()}).parse(req.body); const c=await db.comment.create({data:{videoId,userId:user.id,body:body.body,parentId:body.parentId}}); return reply.status(201).send({data:c});});
app.get('/api/v1/videos/:videoId/comments',async(req)=>{const {videoId}=z.object({videoId:z.string()}).parse(req.params); const comments=await db.comment.findMany({where:{videoId,parentId:null,deletedAt:null},orderBy:{createdAt:'desc'},take:100,include:{user:{select:{username:true,displayName:true,avatarUrl:true}},replies:{where:{deletedAt:null},include:{user:{select:{username:true,displayName:true,avatarUrl:true}}},orderBy:{createdAt:'asc'}}}}); return {data:comments};});

const start=async()=>{await app.listen({port:4000,host:'0.0.0.0'});};
start().catch(async e=>{app.log.error(e);await db.$disconnect();process.exit(1)});
