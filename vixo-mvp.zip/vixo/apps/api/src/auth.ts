import crypto from 'node:crypto';
import argon2 from 'argon2';
import type { FastifyReply, FastifyRequest } from 'fastify';
import { db } from './db.js';
import { env } from './config.js';

const COOKIE='vixo_session';
const hashToken=(t:string)=>crypto.createHash('sha256').update(env.SESSION_SECRET+t).digest('hex');
export async function createSession(userId:string, reply:FastifyReply){
 const token=crypto.randomBytes(32).toString('base64url');
 await db.session.create({data:{userId,tokenHash:hashToken(token),expiresAt:new Date(Date.now()+1000*60*60*24*30)}});
 reply.setCookie(COOKIE,token,{httpOnly:true,secure:env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:60*60*24*30});
}
export async function clearSession(req:FastifyRequest,reply:FastifyReply){
 const token=req.cookies[COOKIE];
 if(token) await db.session.deleteMany({where:{tokenHash:hashToken(token)}});
 reply.clearCookie(COOKIE,{path:'/'});
}
export async function currentUser(req:FastifyRequest){
 const token=req.cookies[COOKIE]; if(!token) return null;
 const session=await db.session.findUnique({where:{tokenHash:hashToken(token)},include:{user:{include:{channel:true}}}});
 if(!session || session.expiresAt<new Date()) return null;
 return session.user;
}
export const hashPassword=(p:string)=>argon2.hash(p,{type:argon2.argon2id,memoryCost:19456,timeCost:2,parallelism:1});
export const verifyPassword=(h:string,p:string)=>argon2.verify(h,p);
