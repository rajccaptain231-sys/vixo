import './globals.css';
import Link from 'next/link';
export const metadata={title:'Vixo — Watch. Create. Connect.',description:'A creator-first video platform.'};
export default function Layout({children}:{children:React.ReactNode}){return <div className="shell"><header className="nav"><Link href="/" className="logo">Vi<span>x</span>o</Link><form className="search" action="/search"><input name="q" placeholder="Search videos, creators and topics" aria-label="Search"/></form><div className="row"><Link href="/upload" className="btn">Create</Link><Link href="/login">Sign in</Link></div></header>{children}</div>}
